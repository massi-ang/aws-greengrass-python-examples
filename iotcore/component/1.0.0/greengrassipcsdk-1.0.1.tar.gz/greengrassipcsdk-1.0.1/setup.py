# Copyright 2021 Amazon.com.
# SPDX-License-Identifier: MIT

#!/usr/bin/env python

from distutils.core import setup

setup(name='greengrassipcsdk',
      version='1.0.1',
      description='Greengrass v2 abstraction library',
      author='Amazon.com',
      author_email='',
      url='https://github.com/aws-greengrass/aws-greengrass-ipc-sdk',
      packages=['greengrassipcsdk'],
      install_requires=['awsiotsdk>=1.5.0,<2.0.0']
     )